
#ifndef HELPER_CPP
#define HELPER_CPP

void random_init();
double rand_0to1();
double loss_function(double* delta);

#endif