#include <cstdlib>

#include "perceptron.h"
#include "constants.h"
#include "helper.h"
#include <iostream>

using namespace std;

Perceptron :: Perceptron(int num) {
    // TODO    
}


double Perceptron :: forward(double* input) {
    // TODO
    return 0;
}

double* Perceptron :: backprop(double delta, double* current_input) {
    // TODO
    
    return weight;
}