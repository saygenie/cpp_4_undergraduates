#include <cmath>
#include "sigmoid.h"

double Sigmoid :: forward(double input) {
    // TODO 
    

    return 0;
}

double Sigmoid :: backprop() {
    // TODO


    return 0;
}