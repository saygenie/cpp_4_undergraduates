#define INPUT_NUM 784    // number of input neurons (28*28)
#define HIDDEN_NUM 128   // number of hidden neurons
#define OUTPUT_NUM 10    // number of output neurons


// modify freely!!
#define EPOCH 40
#define LR 0.01